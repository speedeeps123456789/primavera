# primavera

variable font with a continuous `GROW` axis (0..100), transitioning from bare letterforms (0) to bushes (100).

designed by Edoardo Pensieri.  
based on Cormorant Garamond by Christian Thalmann.

---

## axis

| Axis | Tag | Min | Max | Default |
|---|---|---|---|---|
| Growth | `GROW` | `0` | `100` | `0` |

---

## web use

```css
@font-face {
  font-family: 'primavera';
  src: url('PrimaveraVF.ttf') format('truetype');
  font-display: swap;
}

.text {
  font-family: 'primavera', serif;
  font-variation-settings: 'GROW' 100;
}
```

---

## files

* `PrimaveraVF.ttf` — variable font (`GROW` 0..100)
* `variable/PrimaveraVF.ttf` — variable font
* `static/Primavera-Bare.ttf` — static font (`GROW` 0)
* `static/Primavera-Growth.ttf` — static font (`GROW` 100)
* `OFL.txt` — SIL Open Font License 1.1

---

## license

Licensed under the [SIL Open Font License, Version 1.1](OFL.txt).

Copyright 2015 The Cormorant Project Authors.  
Modifications copyright 2026 Edoardo Pensieri.
